﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcuTable
{
    public partial class Form1 : Form
    {

        String product;
        float unitPrice, priceDelta, subtotal, finalSale = 0;
        int unitCount = 0;

        
        


        public Form1()
        {
            InitializeComponent();
    
            

        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

       
        private void ConveyorQty_TextChanged(object sender, EventArgs e)
        {

        }

        private void FabSheetCost_TextChanged(object sender, EventArgs e)
        {
            unitPrice = float.Parse(FabSheetCost.Text);
            FabSheetTotal.Text = subtotal.ToString();
        }

        private void FabSheetQty_TextChanged(object sender, EventArgs e)
        {
            unitCount = int.Parse(FabSheetQty.Text);
            subtotal = unitCount * unitPrice;
            FabSheetTotal.Text = subtotal.ToString();
        }

        private void FabSheetTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void FabSheetMarkup_TextChanged(object sender, EventArgs e)
        {
            priceDelta = float.Parse(FabSheetMarkup.Text);
            finalSale = priceDelta * subtotal;
            FabSheetSale.Text = "$" + finalSale;

        }

        private void FabSheetSale_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

      

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
